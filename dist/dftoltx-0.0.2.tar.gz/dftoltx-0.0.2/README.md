# dftoltex or Dataframe to LaTex

This is a simple package to translate pandas dataframes into LaTex code. Credit of this idea goes to my fellow developer Frank D'Agostino.
